package com.utt.witchhunt;

public class App {
  public static void main(String[] args) {
    System.out.println("Hello World!");
    System.out.println("ok");
  }
}
