package com.utt.witchhunt.engines;

public enum Side {
	WITCH, HUNT
}
