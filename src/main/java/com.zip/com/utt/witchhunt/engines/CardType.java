package com.utt.witchhunt.engines;

public enum CardType {
	WITCH, HUNT
}
